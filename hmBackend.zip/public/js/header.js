function signIn()
{
        window.location.href = "signIn.html"
    console.log("signin")
}

function becomeMember()
{
    window.location.href = "signUp.html"
    console.log("become a Member")
}

